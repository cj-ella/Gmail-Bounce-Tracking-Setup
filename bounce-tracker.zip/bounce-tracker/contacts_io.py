"""Read/write contacts.csv. Rows are never deleted, only marked."""
import csv
import json
import shutil
from datetime import datetime
from pathlib import Path

COLUMNS = ["email", "organization", "department", "type", "source_url",
           "status", "bounce_code", "bounce_date", "bounce_count", "notes"]
STATUSES = {"active", "bounced", "blocked", "opted_out", "review"}


def load_contacts(path="contacts.csv"):
    with open(path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        for c in COLUMNS:
            r.setdefault(c, "")
        r["status"] = (r["status"] or "active").strip().lower()
        if r["status"] not in STATUSES:
            raise ValueError(f"Bad status {r['status']!r} for {r['email']}")
    return rows


def save_contacts(rows, path="contacts.csv"):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def backup_contacts(path="contacts.csv", folder="backups"):
    Path(folder).mkdir(exist_ok=True)
    dest = Path(folder) / f"contacts_{datetime.now():%Y%m%d-%H%M%S}.csv"
    shutil.copy2(path, dest)
    return dest


def load_processed(path="processed_ids.json"):
    p = Path(path)
    return set(json.loads(p.read_text())) if p.exists() else set()


def save_processed(ids, path="processed_ids.json"):
    Path(path).write_text(json.dumps(sorted(ids), indent=0))


def active_contacts(path="contacts.csv"):
    """Step 10: the draft builder should call this and nothing else."""
    return [r for r in load_contacts(path) if r["status"] == "active"]
