#!/usr/bin/env python3
"""Process Gmail bounce messages into contacts.csv. Plain Python, no Claude tokens.

Dry run by default (writes bounces/report_YYYY-MM-DD.csv only).
Use --apply to back up contacts.csv, update rows and record processed IDs.

    python bounce_processor.py --since 2026-10-01 --until 2026-10-29
    python bounce_processor.py --since 2026-10-01 --until 2026-10-29 --apply --commit
"""
import argparse
import base64
import copy
import csv
import re
import subprocess
from datetime import date
from email import policy
from email.parser import BytesParser
from email.utils import parseaddr, parsedate_to_datetime
from pathlib import Path

from contacts_io import (backup_contacts, load_contacts, load_processed,
                         save_contacts, save_processed)

SCOPES = ["https://www.googleapis.com/auth/gmail.readonly"]  # read-only, on purpose
CREDS, TOKEN = Path("credentials.json"), Path("token.json")
KEYWORD_FALLBACK = True  # plain-text bounces with no code: infer from wording (see classify)

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
CODE_RE = re.compile(r"\b([245]\.\d{1,3}\.\d{1,3})\b")
FULL_RE = re.compile(r"mailbox\s+(is\s+)?full|over\s+quota|quota\s+exceeded|insufficient\s+storage", re.I)
UNKNOWN_RE = re.compile(r"user\s+unknown|no\s+such\s+(user|mailbox|recipient)|does\s+not\s+exist|"
                        r"unknown\s+(user|recipient)|mailbox\s+not\s+found|recipient\s+not\s+found", re.I)


# ---------- step 3: auth ----------
def gmail_service():
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    creds = Credentials.from_authorized_user_file(TOKEN, SCOPES) if TOKEN.exists() else None
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            creds = InstalledAppFlow.from_client_secrets_file(CREDS, SCOPES).run_local_server(port=0)
        TOKEN.write_text(creds.to_json())
    return build("gmail", "v1", credentials=creds)


# ---------- step 4: fetch ----------
def build_query(since, until):
    d = lambda s: s.replace("-", "/")
    return ('(from:(mailer-daemon OR postmaster) OR '
            'subject:("Delivery Status Notification" OR Undeliverable)) '
            f"after:{d(since)} before:{d(until)}")


def search_ids(svc, query):
    ids, token = [], None
    while True:
        r = svc.users().messages().list(userId="me", q=query, pageToken=token).execute()
        ids += [m["id"] for m in r.get("messages", [])]
        token = r.get("nextPageToken")
        if not token:
            return ids


def fetch_raw(svc, mid):
    r = svc.users().messages().get(userId="me", id=mid, format="raw").execute()
    return base64.urlsafe_b64decode(r["raw"])


# ---------- step 5: parse ----------
def _body_text(msg):
    out = []
    for part in msg.walk():
        if part.get_content_type() == "text/plain":
            try:
                out.append(part.get_content())
            except Exception:
                pass
    return "\n".join(out)


def parse_message(msg, known, mid=""):
    """Return a list of events, one per affected contact. known = set of lowercase contact emails."""
    try:
        when = parsedate_to_datetime(msg["Date"]).date().isoformat()
    except Exception:
        when = date.today().isoformat()
    base = {"message_id": mid, "date": when}
    events = []

    # 1) machine-readable DSN part
    for part in msg.walk():
        if part.get_content_type() == "message/delivery-status":
            for block in part.get_payload():
                rcpt = block.get("Final-Recipient") or block.get("Original-Recipient")
                if not rcpt:
                    continue
                addr = rcpt.split(";", 1)[-1].strip().strip("<>").lower()
                events.append({**base, "email": addr, "kind": "dsn",
                               "action": (block.get("Action") or "").strip().lower(),
                               "status": (block.get("Status") or "").strip(),
                               "diagnostic": " ".join(str(block.get("Diagnostic-Code") or "").split())})
    if events:
        return events

    # 2) plain-text bounce: only addresses that exist in contacts.csv
    body = _body_text(msg)
    found = {a.lower() for a in EMAIL_RE.findall(body)} & known
    if found:
        m = CODE_RE.search(body)
        line = next((l.strip() for l in body.splitlines() if m and m.group(1) in l), "")
        diag = " ".join((line or " ".join(body.split()))[:300].split())
        for addr in sorted(found):
            events.append({**base, "email": addr, "kind": "plaintext", "action": "failed",
                           "status": m.group(1) if m else "", "diagnostic": diag,
                           "_text": body})
        return events

    # 3) not a bounce: a normal reply from a known contact (step 12)
    sender = parseaddr(str(msg["From"] or ""))[1].lower()
    if sender in known:
        snippet = " ".join(_body_text(msg).split())[:200]
        return [{**base, "email": sender, "kind": "reply", "action": "", "status": "",
                 "diagnostic": snippet}]
    return []


# ---------- step 6: classify ----------
def classify(ev):
    """Return (rule, outcome). Outcomes: ignore | bounced | soft | blocked | review."""
    if ev["action"] == "delayed":
        return "action=delayed", "ignore"
    if ev["kind"] == "reply":
        return "non-bounce reply", "review"
    code, text = ev["status"], f'{ev["diagnostic"]} {ev.get("_text", "")}'
    if FULL_RE.search(text) or code in ("4.2.2", "5.2.2"):
        return "mailbox full", "soft"
    if code.startswith("5.1."):
        return "5.1.x unknown user", "bounced"
    if code.startswith("4."):
        return "4.x.x temporary", "soft"
    if code.startswith(("5.7.", "5.4.")):
        return "5.7.x/5.4.x block", "blocked"
    if not code and KEYWORD_FALLBACK and UNKNOWN_RE.search(text):
        return "keyword: unknown user (no code)", "bounced"
    return "unplaced", "review"


def apply_outcome(row, ev, rule, outcome):
    """Mutate row in place. opted_out is never touched; bounced is never downgraded."""
    if row["status"] == "opted_out" or outcome == "ignore":
        return
    note = lambda t: row.__setitem__("notes", "; ".join(x for x in [row["notes"], f'{ev["date"]} {t}'] if x))
    if ev["status"]:
        row["bounce_code"] = ev["status"]
    row["bounce_date"] = ev["date"]
    n = int(row["bounce_count"] or 0)
    if outcome == "bounced":
        row["status"] = "bounced"
    elif outcome == "soft":
        row["bounce_count"] = str(n + 1)
        if n + 1 >= 2 and row["status"] == "active":
            row["status"] = "review"
    elif outcome == "blocked":
        if row["status"] != "bounced":
            row["status"] = "blocked"
    elif outcome == "review":
        if row["status"] == "active":
            row["status"] = "review"
        note(f"review: {rule}")


# ---------- step 7: report ----------
REPORT_COLS = ["message_id", "email", "code", "diagnostic", "rule",
               "old_status", "new_status", "bounce_count", "proposed_change"]


def process(events_by_msg, contacts):
    """Run rules on a COPY of contacts. Returns (new_rows, report_rows)."""
    rows = copy.deepcopy(contacts)
    index = {r["email"].lower(): r for r in rows}
    report = []
    for mid, events in events_by_msg.items():
        if not events:
            report.append({"message_id": mid, "rule": "no contact matched", "proposed_change": "none"})
        for ev in events:
            row = index.get(ev["email"])
            rule, outcome = classify(ev)
            if not row:
                report.append({"message_id": mid, "email": ev["email"], "code": ev["status"],
                               "diagnostic": ev["diagnostic"], "rule": rule,
                               "proposed_change": "email not in contacts.csv"})
                continue
            old, old_n = row["status"], row["bounce_count"]
            apply_outcome(row, ev, rule, outcome)
            parts = []
            if row["status"] != old:
                parts.append(f"{old} -> {row['status']}")
            if row["bounce_count"] != old_n:
                parts.append(f"bounce_count {old_n or 0} -> {row['bounce_count']}")
            report.append({"message_id": mid, "email": ev["email"], "code": ev["status"],
                           "diagnostic": ev["diagnostic"], "rule": rule, "old_status": old,
                           "new_status": row["status"], "bounce_count": row["bounce_count"],
                           "proposed_change": "; ".join(parts) or "none"})
    return rows, report


def write_report(report, folder="bounces"):
    Path(folder).mkdir(exist_ok=True)
    path = Path(folder) / f"report_{date.today():%Y-%m-%d}.csv"
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=REPORT_COLS)
        w.writeheader()
        w.writerows(report)
    return path


def summary(report):
    count = lambda s: sum(1 for r in report if r.get("new_status") == s and r["old_status"] != s)
    return f"Bounce update, {count('bounced')} bounced, {count('blocked')} blocked, {count('review')} review"


# ---------- main ----------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--since", required=True, help="YYYY-MM-DD")
    ap.add_argument("--until", required=True, help="YYYY-MM-DD (exclusive, Gmail 'before:')")
    ap.add_argument("--apply", action="store_true", help="write changes (default is dry run)")
    ap.add_argument("--commit", action="store_true", help="git commit after --apply")
    a = ap.parse_args()

    contacts, processed = load_contacts(), load_processed()
    known = {r["email"].lower() for r in contacts}
    svc = gmail_service()
    ids = [i for i in search_ids(svc, build_query(a.since, a.until)) if i not in processed]
    print(f"{len(ids)} new messages to process")

    parser = BytesParser(policy=policy.default)
    events_by_msg = {mid: parse_message(parser.parsebytes(fetch_raw(svc, mid)), known, mid) for mid in ids}
    new_rows, report = process(events_by_msg, contacts)
    path = write_report(report)
    msg = summary(report)
    print(f"{msg}\nReport: {path}")

    if not a.apply:
        print("Dry run: contacts.csv unchanged. Check the report, then rerun with --apply.")
        return
    print(f"Backup: {backup_contacts()}")
    save_contacts(new_rows)
    save_processed(processed | set(ids))
    if a.commit:
        subprocess.run(["git", "add", "contacts.csv", "processed_ids.json", "bounces/"], check=True)
        subprocess.run(["git", "commit", "-m", msg], check=True)


if __name__ == "__main__":
    main()
