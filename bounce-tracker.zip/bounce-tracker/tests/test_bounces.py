"""Run: python -m unittest discover -s tests -v
Synthetic emails below stand in for your redacted real ones. Drop real samples in
tests/fixtures/*.eml and add a test per file using load_fixture()."""
import sys
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import bounce_processor as bp  # noqa: E402

KNOWN = {"jane@uni.edu", "bob@uni.edu", "amy@college.edu", "sam@org.org", "lee@uni.edu"}


def dsn(rcpt, action, status, diag):
    return f"""From: MAILER-DAEMON@mx.example.com
To: me@example.com
Subject: Delivery Status Notification (Failure)
Date: Mon, 12 Oct 2026 10:00:00 +0000
MIME-Version: 1.0
Content-Type: multipart/report; report-type=delivery-status; boundary="B"

--B
Content-Type: text/plain

Your message could not be delivered. Footer: office@sender-org.org

--B
Content-Type: message/delivery-status

Reporting-MTA: dns; mx.example.com

Final-Recipient: rfc822; {rcpt}
Action: {action}
Status: {status}
Diagnostic-Code: smtp; {diag}

--B--
""".encode()


PLAIN_UNI = b"""From: postmaster@uni.edu
To: me@example.com
Subject: Undeliverable: hello
Date: Tue, 13 Oct 2026 09:00:00 +0000
Content-Type: text/plain

Delivery failed for amy@college.edu: user unknown.
Contact helpdesk@uni.edu or postmaster@uni.edu for help.
"""

REPLY = b"""From: Sam <sam@org.org>
To: me@example.com
Subject: Re: hello
Date: Wed, 14 Oct 2026 09:00:00 +0000
Content-Type: text/plain

I've left the organisation, please contact Jane instead.
"""


def parse(raw, mid="m1"):
    return bp.parse_message(BytesParser(policy=policy.default).parsebytes(raw), KNOWN, mid)


def row(email, status="active", count="0"):
    return {"email": email, "organization": "", "department": "", "type": "", "source_url": "",
            "status": status, "bounce_code": "", "bounce_date": "", "bounce_count": count, "notes": ""}


def run(raw, **kw):
    ev = parse(raw)
    rows, report = bp.process({"m1": ev}, [row(e) if e not in kw else kw[e] for e in sorted(KNOWN)])
    return ev, {r["email"]: r for r in rows}, report


class Tests(unittest.TestCase):
    def test_hard_bounce(self):
        ev, rows, _ = run(dsn("jane@uni.edu", "failed", "5.1.1", "550 5.1.1 User unknown"))
        self.assertEqual(rows["jane@uni.edu"]["status"], "bounced")
        self.assertEqual(rows["jane@uni.edu"]["bounce_code"], "5.1.1")
        self.assertEqual(rows["jane@uni.edu"]["bounce_date"], "2026-10-12")

    def test_mailbox_full_counts_then_reviews(self):
        raw = dsn("bob@uni.edu", "failed", "4.2.2", "452 4.2.2 Mailbox full")
        _, rows, _ = run(raw)
        self.assertEqual((rows["bob@uni.edu"]["status"], rows["bob@uni.edu"]["bounce_count"]), ("active", "1"))
        _, rows, _ = run(raw, **{"bob@uni.edu": row("bob@uni.edu", count="1")})
        self.assertEqual((rows["bob@uni.edu"]["status"], rows["bob@uni.edu"]["bounce_count"]), ("review", "2"))

    def test_spam_block(self):
        _, rows, _ = run(dsn("lee@uni.edu", "failed", "5.7.1", "550 5.7.1 blocked by policy"))
        self.assertEqual(rows["lee@uni.edu"]["status"], "blocked")

    def test_delayed_ignored(self):
        _, rows, report = run(dsn("jane@uni.edu", "delayed", "4.4.1", "connection timed out"))
        self.assertEqual(rows["jane@uni.edu"]["status"], "active")
        self.assertEqual(rows["jane@uni.edu"]["bounce_count"], "0")
        self.assertEqual(report[0]["proposed_change"], "none")

    def test_plaintext_only_known_contacts(self):
        ev = parse(PLAIN_UNI)
        self.assertEqual([e["email"] for e in ev], ["amy@college.edu"])  # not helpdesk/postmaster
        _, rows, _ = run(PLAIN_UNI)
        self.assertEqual(rows["amy@college.edu"]["status"], "bounced")

    def test_footer_address_ignored(self):
        ev = parse(dsn("jane@uni.edu", "failed", "5.1.1", "no such user"))
        self.assertEqual([e["email"] for e in ev], ["jane@uni.edu"])

    def test_non_bounce_reply_goes_to_review(self):
        ev, rows, _ = run(REPLY)
        self.assertEqual(ev[0]["kind"], "reply")
        self.assertEqual(rows["sam@org.org"]["status"], "review")

    def test_unplaced_code_goes_to_review(self):
        _, rows, _ = run(dsn("jane@uni.edu", "failed", "5.3.4", "message too big"))
        self.assertEqual(rows["jane@uni.edu"]["status"], "review")

    def test_opted_out_and_bounced_protected(self):
        raw = dsn("jane@uni.edu", "failed", "5.7.1", "blocked")
        _, rows, _ = run(raw, **{"jane@uni.edu": row("jane@uni.edu", "opted_out")})
        self.assertEqual(rows["jane@uni.edu"]["status"], "opted_out")
        _, rows, _ = run(raw, **{"jane@uni.edu": row("jane@uni.edu", "bounced")})
        self.assertEqual(rows["jane@uni.edu"]["status"], "bounced")

    def test_query(self):
        q = bp.build_query("2026-10-01", "2026-10-29")
        self.assertIn("mailer-daemon", q)
        self.assertIn("Undeliverable", q)
        self.assertIn("after:2026/10/01", q)


if __name__ == "__main__":
    unittest.main()
