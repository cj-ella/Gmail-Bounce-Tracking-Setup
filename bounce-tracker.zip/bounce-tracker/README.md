# bounce-tracker (private repo: contains contact emails)

Setup: `pip install -r requirements.txt`, put Google's `credentials.json` here (gitignored; first run creates `token.json`).

    python bounce_processor.py --since 2026-10-01 --until 2026-10-29            # dry run -> bounces/report_DATE.csv
    python bounce_processor.py --since 2026-10-01 --until 2026-10-29 --apply --commit
    python -m unittest discover -s tests -v

Draft builder: `from contacts_io import active_contacts` (status == active only).
